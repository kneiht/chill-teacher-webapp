import"./index-D9NlG0rl.js";const n=()=>null;export{n as component};
