import{bn as o}from"./index-CYtSkMOB.js";const s=()=>{console.log(o.get("accessToken"));const e=o.get("accessToken");return e?{Authorization:`Bearer ${e}`}:{}};export{s as g};
