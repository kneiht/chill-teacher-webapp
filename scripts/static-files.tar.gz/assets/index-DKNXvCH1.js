import"./index-BvYG23Ym.js";const n=()=>null;export{n as component};
