import"./index-CYtSkMOB.js";const n=()=>null;export{n as component};
